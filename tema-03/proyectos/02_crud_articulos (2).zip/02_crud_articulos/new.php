<?php

/**
 * new.php
 * Mostrará un formulario en blanco que permita introducir los detalles del nuevo ARTÍCULO.
 */

// Cargar librerías
require_once 'libs/funciones_articulos.php';

// Negociado (obtener categorías para el select)
$categorias = generar_tabla_categorias();

// Cargar la vista del formulario
require_once 'views/form_nuevo.view.php';