<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cálculo Lanzamiento de Proyectiles</title>

    <!-- css bootstrap basico 5.3.8 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    
    <!-- icons bootstrap basico 5.3.8 -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
</head>
  <body>
  <!-- capa principal de la aplicacion -->
  <div class="container mt-3">

    <header class="bg-primary text-white p-3 mb-3">
        <i class="bi bi-rocket-takeoff-fill"></i>
        <span class="fs-6">Proyecto 2.2 - Cálculo Lanzamiento de Proyectiles</span>
    </header>
    

    <! -- contenido principal de la aplicacion -- >
    <main>
        <div class="content">
            <!-- Formulario de la calculadora -->
             <form method="post">
                <!-- Campo velocidad inicial    -->
                 <div class="mb-3">
                    <label for="velocidad_inicial" class="form-label">Velocidad Inicial:</label>
                    <input type="number" class="form-control" step="0.01" placeholder="0.00" id="velocidad_inicial" name="velocidad_inicial" required>
                    <small id="helpId" class=text-muted">Velocidad en m/s</small>
                 </div>

                 <!-- Campo ángulo de lanzamiento   -->
                 <div class="mb-3">
                    <label for="angulo_lanzamiento" class="form-label">Ángulo de lanzamiento:</label>
                    <input type="number" class="form-control" step="0.01" placeholder="0.00" id="angulo_lanzamiento" name="angulo_lanzamiento" required>
                    <small id="helpId" class=text-muted">Ángulo en grados</small>
                 </div>

                 <!-- Botones de acción -->
                  <div class="btn-group" role="group">
                    <button type="reset" class="btn btn-danger">Borrar</button>
                    <button type="submit" class="btn btn-warning" name="operacion" value="calcular" formaction="calcular.php">Cálculos del Lanzamiento</button>


                  </div>
             </form>
        </div>
    </main>

    <!-- Pie de página -->
    <footer class="footer mt-auto py-3 fixed-bottom bg-light">
      <div class="container">
        <span class="text-muted">&copy; 2026
            Adrian Campos Espejo - DWES - 2º DAW - Curso 26/27
        </span>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>


  </div>
  </body>
</html>